cd C:\Users\4097084\code\data_analysis\dataviz
C:/Users/4097084/AppData/Local/Programs/Python/Python39/python.exe -m streamlit run main.py