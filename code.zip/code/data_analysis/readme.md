                <style>
                    /* 定义悬浮文本框的样式 */
                    .floating-box {
                        position: fixed;
                        bottom: 20px;
                        right: 20px;
                        width: 200px;
                        padding: 10px;
                        background-color: #f9f9f9;
                        border: 1px solid #ccc;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    }
                </style>

    
</head>
<body >
        <!-- 悬浮注释-->
        <div class="floating-box">
            节点从上到下按出现频次多少排序
        </div>